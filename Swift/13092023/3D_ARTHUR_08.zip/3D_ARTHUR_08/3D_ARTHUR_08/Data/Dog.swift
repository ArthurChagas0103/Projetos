struct Dog: Codable {
    let message, status: String
}
