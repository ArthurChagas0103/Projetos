const { response } = require("express");
const User = require("./api/database/User");

history.pushState(null, null, document.URL);
window.addEventListener('popstate', function () {
    history.pushState(null, null, document.URL);
});

function limitadorMatricula() {
    var matricula = document.getElementById("codMatricula").value;

    matricula = matricula.slice(0, 8);

    document.getElementById("codMatricula").value = matricula;

    matricula = document.getElementById("codMatricula").value.slice(0, 8);
}

function limitadorTurma() {
    var turma = document.getElementById("turma").value;

    turma = turma.slice(0, 3);

    document.getElementById("turma").value = turma;

    turma = document.getElementById("turma").value.slice(0, 3);
}

function validar() {
    var matricula = document.getElementById("codMatricula").value;
    var nome = document.getElementById("nome_completo").value;
    var turma = document.getElementById("turma").value;

    if (matricula == "") {
        alert('Atenção! Digite sua matrícula!');
        return false
    }
    else if (nome == "") {
        alert('Atenção! Digite seu nome completo!');
        return false
    }
    else if (turma == "") {
        alert('Atenção! Digite sua turma!');
        return false
    }
    else {
        const thisForm = document.getElementById('formsLogin');

        thisForm.addEventListener('submit', function (e) {
            e.preventDefault();

            const formData = {
                codMatricula: matricula,
                nome_completo: nome,
                turma: turma
            }

            console.log(formData)

            fetch('http://localhost:3000/validador', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(formData),
            }).then(res => res.json())
                .then(data => {
                    if (data.code == 200) {
                        console.log(data)
                        localStorage.setItem("codMatricula", data.matricula);

                        if (matricula == "00000000" && nome == "admin" && turma == "adm") {
                            window.open('/front-end/admin/admin.html', '_self');
                        }
                        else {
                            window.open('/front-end/vote/vote.html', '_self');
                        }
                    }
                    else {
                        alert('Login não confere ou voto já realizado!')
                    }
                })
        });
    }
}