function mostrar() {
    const thisForm = document.getElementById('formsScore');

    thisForm.addEventListener('submit', async function (e) {
        e.preventDefault();
        // const formData = new FormData(thisForm).entries()

        const response = fetch('http://localhost:3000/apuracao-votos', {
            method: 'GET',
            headers: { 'Content-Type': 'application/json' }
        }).then(res => res.json())
            .then(data => {
                console.log(data)

                let html = "<table style='border: 1px solid; box-shadow: rgba(99, 99, 99, 0.2) 0px 2px 8px 0px; margin-top: 5%; text-align: center ' class='table'>";

                data.map(m =>
                    html += "<tr class='titulo'><td>" + "Numero Urna Candidato" + "</td><td>" + "Quantidade de Votos" + "</td></tr>" + "<tr><td>" + m.numero_urna_candidato_fk + "</td><td>" + m.quantidade + "</td></tr>",
                )

                html += "</table>"

                document.getElementById('foo').innerHTML = html
                console.log(html)
            })
        console.log(response)
    });
}

function fechar() {
    close();
}



