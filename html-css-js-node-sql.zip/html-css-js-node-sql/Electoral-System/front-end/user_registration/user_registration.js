

function validar() {
    var numero = document.getElementById("codMatricula").value;
    var nome_completo = document.getElementById("nome_completo").value;
    var turma = document.getElementById("turma").value;

    if (numero == "") {
        alert('Digite o número da urna do candidato!');
        numero.focus();
        return false
    }
    if (nome_completo == "") {
        alert('Digite o nome completo do candidato!');
        nome_completo.focus();
        return false
    }
    if (turma == "") {
        alert('Digite a turma!');
        turma.focus();
        return false
    }
    else {
        const thisForm = document.getElementById('formsCadastro');

        thisForm.addEventListener('submit', async function (e) {
            e.preventDefault();

            const formData = new FormData(thisForm).entries()

            const response = fetch('http://localhost:3000/cadastrar-usuario', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(Object.fromEntries(formData)),
            })

            console.log('response.status: ', response.status);
            console.log(response);

            if ((await response).status == 200) {
                alert('Cadastro realizado com sucesso!');
                thisForm.reset();
            }
            else {
                alert('Cadastro não realizado com sucesso!');
            }
        });
    }
}

function limitadorCodMatricula() {
    var numero = document.getElementById("codMatricula").value;

    numero = numero.slice(0, 8);

    document.getElementById("codMatricula").value = numero;

    numero = document.getElementById("codMatricula").value.slice(0, 8);
}

function limitadorTurma() {
    var turma = document.getElementById("turma").value;

    turma = turma.slice(0, 3);

    document.getElementById("turma").value = turma;

    turma = document.getElementById("turma").value.slice(0, 3);
}

function fechar() {
    close();
}  