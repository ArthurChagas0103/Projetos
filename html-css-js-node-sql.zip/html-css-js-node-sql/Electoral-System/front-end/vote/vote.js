const { response } = require("express");
localStorage.getItem("codMatricula");

history.pushState(null, null, document.URL);
window.addEventListener('popstate', function () {
    history.pushState(null, null, document.URL);
});


function mensagem() {
    var mensagem = confirm("Tem certeza que gostaria de voltar para a tela de login?");

    if (mensagem == true) {
        window.open("/index.html");
        close()
    }
    else {
        return false;
    }
}

function limitadorVoto() {
    var numero = document.getElementById("numero_urna_candidato_fk").value;

    numero = numero.slice(0, 2);

    document.getElementById("numero_urna_candidato_fk").value = numero;

    numero = document.getElementById("numero_urna_candidato_fk").value.slice(0, 2);
}

function fotoPresidente() {
    var numero = document.getElementById("numero_urna_candidato_fk").value;

    if (numero == "" || numero == 1 || numero == 3 || numero == 2 || numero == 8 || numero == 4 || numero == 0) {
        document.getElementById("textCiroGomes").style.display = "none";
        document.getElementById("ciroGomes").style.display = "none";
        document.getElementById("textFelipeAvila").style.display = "none";
        document.getElementById("felipeAvila").style.display = "none";
        document.getElementById("bolsonaro").style.display = "none";
        document.getElementById("textBolsonaro").style.display = "none";
        document.getElementById("joseMaria").style.display = "none";
        document.getElementById("textJoseMaria").style.display = "none";
        document.getElementById("leoPericles").style.display = "none";
        document.getElementById("textLeoPericles").style.display = "none";
        document.getElementById("lula").style.display = "none";
        document.getElementById("textLula").style.display = "none";
        document.getElementById("pabloMarcal").style.display = "none";
        document.getElementById("textPabloMarcal").style.display = "none";
        document.getElementById("padreKelmon").style.display = "none";
        document.getElementById("textpadreKelmon").style.display = "none";
        document.getElementById("simone").style.display = "none";
        document.getElementById("textSimone").style.display = "none";
        document.getElementById("sofia").style.display = "none";
        document.getElementById("textSofia").style.display = "none";
        document.getElementById("soraya").style.display = "none";
        document.getElementById("textSoraya").style.display = "none";
        document.getElementById("veraLucia").style.display = "none";
        document.getElementById("textVeraLucia").style.display = "none";
        document.getElementById("votoNulo").style.display = "none";
        document.getElementById("textVotoNulo").style.display = "none";
    }
    if (numero == "12") {
        document.getElementById("ciroGomes").style.display = "block";
        document.getElementById("textCiroGomes").style.display = "block";
    }
    else if (numero == "30") {
        document.getElementById("felipeAvila").style.display = "block";
        document.getElementById("textFelipeAvila").style.display = "block";
    }
    else if (numero == "22") {
        document.getElementById("bolsonaro").style.display = "block";
        document.getElementById("textBolsonaro").style.display = "block";
    }
    else if (numero == "27") {
        document.getElementById("joseMaria").style.display = "block";
        document.getElementById("textJoseMaria").style.display = "block";
    }
    else if (numero == "80") {
        document.getElementById("leoPericles").style.display = "block";
        document.getElementById("textLeoPericles").style.display = "block";
    }
    else if (numero == "13") {
        document.getElementById("lula").style.display = "block";
        document.getElementById("textLula").style.display = "block";
    }
    else if (numero == "14") {
        document.getElementById("padreKelmon").style.display = "block";
        document.getElementById("textpadreKelmon").style.display = "block";
    }
    else if (numero == "15") {
        document.getElementById("simone").style.display = "block";
        document.getElementById("textSimone").style.display = "block";
    }
    else if (numero == "21") {
        document.getElementById("sofia").style.display = "block";
        document.getElementById("textSofia").style.display = "block";
    }
    else if (numero == "44") {
        document.getElementById("soraya").style.display = "block";
        document.getElementById("textSoraya").style.display = "block";
    }
    else if (numero == "16") {
        document.getElementById("veraLucia").style.display = "block";
        document.getElementById("textVeraLucia").style.display = "block";
    }
    else if (numero == "00") {
        document.getElementById("votoNulo").style.display = "block";
        document.getElementById("textVotoNulo").style.display = "block";
    }
}

function enviar() {
    var numero = document.getElementById("numero_urna_candidato_fk").value;

    if (numero == "12" || numero == "30" || numero == "22" || numero == "27" || numero == "80" || numero == "13" || numero == "14" || numero == "15" || numero == "21" || numero == "44" || numero == "16" || numero == "00") {
        const thisForm = document.getElementById('formsVoto');

        thisForm.addEventListener('submit', async function (e) {
            e.preventDefault();

            const formData = new FormData(thisForm).entries()

            const response = fetch('http://localhost:3000/atualizar-voto', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(Object.fromEntries(formData)),
            })
            console.log('response.status: ', response.status);
            console.log(response);

            if ((await response).status == 200) {
                alert('Voto realizado com sucesso!');
                window.open('/index.html', '_self')
            }
            else {
                alert('Voto não realizado com sucesso!');
            }
        });
    }
    else {
        alert('Candidato não existe!')
    }
}

function apagar() {
    document.getElementById("textCiroGomes").style.display = "none";
    document.getElementById("ciroGomes").style.display = "none";
    document.getElementById("textFelipeAvila").style.display = "none";
    document.getElementById("felipeAvila").style.display = "none";
    document.getElementById("bolsonaro").style.display = "none";
    document.getElementById("textBolsonaro").style.display = "none";
    document.getElementById("joseMaria").style.display = "none";
    document.getElementById("textJoseMaria").style.display = "none";
    document.getElementById("leoPericles").style.display = "none";
    document.getElementById("textLeoPericles").style.display = "none";
    document.getElementById("lula").style.display = "none";
    document.getElementById("textLula").style.display = "none";
    document.getElementById("pabloMarcal").style.display = "none";
    document.getElementById("textPabloMarcal").style.display = "none";
    document.getElementById("padreKelmon").style.display = "none";
    document.getElementById("textpadreKelmon").style.display = "none";
    document.getElementById("simone").style.display = "none";
    document.getElementById("textSimone").style.display = "none";
    document.getElementById("sofia").style.display = "none";
    document.getElementById("textSofia").style.display = "none";
    document.getElementById("soraya").style.display = "none";
    document.getElementById("textSoraya").style.display = "none";
    document.getElementById("veraLucia").style.display = "none";
    document.getElementById("textVeraLucia").style.display = "none";
    document.getElementById("votoNulo").style.display = "none";
    document.getElementById("textVotoNulo").style.display = "none";
}