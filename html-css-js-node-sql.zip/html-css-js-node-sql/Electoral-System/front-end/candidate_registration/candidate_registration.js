function validar() {
    var numero = document.getElementById("numero_urna").value;
    var nome_completo = document.getElementById("nome_completo").value;
    var partido = document.getElementById("partido").value;
    var nome_urna = document.getElementById("nome_urna").value;

    if (numero == "") {
        alert('Digite o número da urna do candidato');
        numero.focus();
        return false
    }
    else if (nome_completo == "") {
        alert('Digite o nome completo do candidato');
        nome_completo.focus();
        return false
    }
    else if (partido == "") {
        alert('Digite o partido do candidato');
        partido.focus();
        return false
    }
    else if (nome_urna == "") {
        alert('Digite o nome na urna do candidato');
        nome_urna.focus();
        return false
    }
    else {
        const thisForm = document.getElementById('formsCadastro');

        thisForm.addEventListener('submit', async function (e) {
            e.preventDefault();

            const formData = new FormData(thisForm).entries()

            const response = fetch('http://localhost:3000/cadastrar-candidato', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(Object.fromEntries(formData)),
            })

            console.log('response.status: ', response.status);
            console.log(response);

            if ((await response).status == 200) {
                alert('Cadastro realizado com sucesso!');
                numero.value = "";
                nome_completo.value = "";
                partido.value = "";
                nome_urna.value = "";
            }
            else {
                alert('Cadastro não realizado com sucesso!');
            }
        });
    }
}

function limitadorNumeroUrna() {
    var numero = document.getElementById("numero_urna").value;

    numero = numero.slice(0, 2);

    document.getElementById("numero_urna").value = numero;

    numero = document.getElementById("numero_urna").value.slice(0, 2);
}

function limitadorPartido() {
    var partido = document.getElementById("partido").value;

    partido = partido.slice(0, 5);

    document.getElementById("partido").value = partido;

    partido = document.getElementById("partido").value.slice(0, 5);
}

function fechar() {
    close();
}  