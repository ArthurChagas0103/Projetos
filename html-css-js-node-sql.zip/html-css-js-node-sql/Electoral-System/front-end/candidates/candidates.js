function fechar(){
    close();
}