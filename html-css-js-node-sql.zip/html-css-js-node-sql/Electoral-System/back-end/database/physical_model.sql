create database eleicao;

select * from usuarios;

select * from candidatos;

select * from votos;