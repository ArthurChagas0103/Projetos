const express = require('express');
const Candidate = require('./database/Candidate');
const app = express();
const port = 3000;
const User = require('./database/User');
const cors = require('cors');
const { response } = require('express');
const { ValidationError } = require('sequelize');
const Vote = require('./database/Vote');

app.use(cors());

app.use(express.json());

app.get("/", async (req, res) => {
    res.send("Funcionando!");
});

app.post("/cadastrar-usuario", async (req, res) => {
    await User.create(req.body)
        .then(() => {
            console.log('Cadastro realizado com sucesso!')
            res.send({
                code: 200,
            });
        }).catch(() => {
            console.log('Cadastro não realizado com sucesso!')
            res.status(400)
            res.send({
                code: 400
            });
        });
});

app.post("/cadastrar-candidato", async (req, res) => {
    await Candidate.create(req.body)
        .then(() => {
            console.log('Cadastro realizado com sucesso!')
            res.send({
                code: 200,
            });
        }).catch(() => {
            console.log('Cadastro não realizado com sucesso!')
            res.status(400)
            res.send({
                code: 400
            });
        });
});

app.listen(port, () => {
    console.log("Servidor iniciado na porta 3000: http://localhost:3000");
});

app.post("/validador", async (req, res) => {
    console.log(req.body)

    const users = await User.findOne({
        attributes: ['codMatricula', 'nome_completo', 'turma', 'numero_de_votos'],
        where: {
            codMatricula: req.body.codMatricula,
            nome_completo: req.body.nome_completo,
            turma: req.body.turma,
            numero_de_votos: 0
        }
    });
    if (users === null) {
        console.log('Login não confere ou voto já realizado')
        res.status(400)
        res.send({
            code: 400
        });
    }
    else {
        await User.update({
            numero_de_votos: 1,
        }, {
            where: {
                codMatricula: req.body.codMatricula
            }
        })
        if (users.codMatricula == 00000000) {
            await User.update({
                numero_de_votos: 0,
            }, {
                where: {
                    codMatricula: req.body.codMatricula
                }
            })
        }
        console.log('Login confere')
        res.send({
            code: 200,
            matricula: users.codMatricula
        });
    }
});

app.post("/criar-voto", async (req, res) => {
    await Vote.create(req.body)
        .then(() => {
            console.log('Voto criado com sucesso!')
            res.send({
                code: 200,
            });
        }).catch(() => {
            console.log('Voto não criado com sucesso!')
            res.status(400)
            res.send({
                code: 400
            });
        });
});

app.post("/atualizar-voto", async (req, res) => {

    const voto = await Vote.findOne({
        attributes: ['numero_urna_candidato_fk', 'quantidade'],
        where: {
            numero_urna_candidato_fk: req.body.numero_urna_candidato_fk
        },
        raw: true
    })

    await Vote.update({
        quantidade: voto.quantidade + 1,
    }, {
        where: {
            numero_urna_candidato_fk: req.body.numero_urna_candidato_fk
        }
    })
        .then(() => {
            console.log('Voto registrado com sucesso!')
            res.send({
                code: 200
            });
        }).catch(() => {
            console.log('Voto não registrado com sucesso!')
            res.status(400)
            res.send({
                code: 400
            });
        });
});

app.get("/usuarios", async (req, res) => {
    const users = await User.findAll();
    console.log(users.every(user => user instanceof User));
    console.log("All users:", JSON.stringify(users, null, 2));
});

app.get("/candidates", async (req, res) => {
    const candidates = await Candidate.findAll();
    console.log(candidates.every(candidates => candidates instanceof Candidate));
    console.log("All candidates:", JSON.stringify(candidates, null, 2))
});

app.get("/apuracao-votos", async (req, res) => {
    const votos = await Vote.findAll({
        attributes: ['quantidade', 'numero_urna_candidato_fk'],
        raw: true
    });
    console.log(votos.every(votos => votos instanceof Vote));
    console.log("All votos:", JSON.stringify(votos, null, 2));
    res.send(votos)
});