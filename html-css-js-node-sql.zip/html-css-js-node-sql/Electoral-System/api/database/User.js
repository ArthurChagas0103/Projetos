const Sequelize = require('sequelize');
const db = require('./connection');

const User = db.define('usuario', {
    codMatricula: {
        type: Sequelize.CHAR(8),
        autoIncrement: false,
        allowNull: false,
        primaryKey: true
    },
    nome_completo: {
        type: Sequelize.STRING(200),
        allowNull: false,
    },
    turma: {
        type: Sequelize.CHAR(3),
        allowNull: false,
    },
    numero_de_votos: {
        type: Sequelize.CHAR(1),
        allowNull: false,
    },
});

//Descomente para criar a tabela
//User.sync();

module.exports = User;