const Sequelize = require('sequelize');
const db = require('./connection');
const Candidate = require('./Candidate');

const Vote = db.define('voto', {
    id_votos: {
        type: Sequelize.INTEGER,
        autoIncrement: true,
        allowNull: false,
        primaryKey: true
    },
    quantidade: {
        type: Sequelize.INTEGER,
        allowNull: false,
    },
    numero_urna_candidato_fk: {
        type: Sequelize.INTEGER,
        allowNull: false,
    },
}, {
    classMethods: {
        associate: (model) => {
            Vote.belongsTo(model.Candidate, { foreignKey: 'numero_urna_candidato_fk' })
        }
    }
});

//Descomente para criar a tabela
//Vote.sync();

module.exports = Vote;