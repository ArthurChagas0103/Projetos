const Sequelize = require('sequelize');
const db = require('./connection');

const Candidate = db.define('candidato', {
    numero_urna: {
        type: Sequelize.CHAR(2),
        autoIncrement: false,
        allowNull: false,
        primaryKey: true
    },
    nome_completo: {
        type: Sequelize.STRING(200),
        allowNull: false,
    },
    partido: {
        type: Sequelize.STRING(5),
        allowNull: false,
    },
    nome_urna: {
        type: Sequelize.STRING(200),
        allowNull: false,
    },
});

//Descomente para criar a tabela
//Candidate.sync(); 

module.exports = Candidate;